<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Booking Successful!</h2>
    <p>Your bus has been booked successfully.</p>
    <br>
    <a href="dashboard.php">Return to Dashboard</a>
</body>
</html>
